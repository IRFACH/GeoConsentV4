import os
from tools.base import Tool

class OpenApp(Tool):
    name = "open_app"
    description = "Open an Android app by package name"

    def run(self, args):
        package = args.get("package")
        if not package:
            return "No package name provided"
        os.system(f"am start -n {package}")
        return "App opened"


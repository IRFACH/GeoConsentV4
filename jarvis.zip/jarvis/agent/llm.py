import json
import openai
from agent.system_prompt import SYSTEM_PROMPT
from agent.tools_schema import get_tools_schema

# 🔴 PUT YOUR API KEY HERE
openai.api_key = "PASTE_YOUR_OPENAI_API_KEY"

def call_llm(user_input):
    tools = get_tools_schema()

    prompt = f"""
Available tools:
{json.dumps(tools, indent=2)}

User input:
"{user_input}"
"""

    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ],
        temperature=0.2
    )

    content = response.choices[0].message.content
    return json.loads(content)


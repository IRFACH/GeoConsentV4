from agent.planner import plan
from tools.android import OpenApp

TOOLS = {
    "open_app": OpenApp()
}

class JarvisAgent:
    def process(self, user_input):
        plan_data = plan(user_input)

        for step in plan_data.get("steps", []):
            tool = TOOLS.get(step.get("tool"))
            if tool:
                tool.run(step.get("args", {}))

        return plan_data.get("final_response", "")


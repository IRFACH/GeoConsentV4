from agent.llm import call_llm

def plan(user_input):
    return call_llm(user_input)


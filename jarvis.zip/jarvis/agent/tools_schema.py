def get_tools_schema():
    return [
        {
            "name": "open_app",
            "description": "Open an Android app using its package name",
            "args": {
                "package": "Android package name (string)"
            }
        }
    ]


from agent.agent import JarvisAgent

jarvis = JarvisAgent()

print("Jarvis is online. Type 'exit' to stop.")

while True:
    user_input = input("You: ")

    if user_input.lower() in ["exit", "stop"]:
        print("Jarvis: Goodbye.")
        break

    response = jarvis.process(user_input)
    print("Jarvis:", response)

